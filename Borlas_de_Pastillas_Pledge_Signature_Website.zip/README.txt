BORLAS DE PASTILLAS — PLEDGE + SIGNATURE WEBSITE

Open index.html in a browser.

This version is intentionally focused on:
- A preservation pledge
- Name/display-name signup
- Hand-drawn signature canvas
- A digital preservation wall
- Local browser storage for demo purposes

IMPORTANT:
The signatures are stored only in the visitor's browser using localStorage.
They are NOT sent to a central database. For a real public advocacy campaign,
a backend/database and privacy notice should be added before collecting public submissions.
